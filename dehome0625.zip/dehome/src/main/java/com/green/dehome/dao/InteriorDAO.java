package com.green.dehome.dao;

import java.util.List;

import com.green.dehome.dto.InteriorDTO;


public interface InteriorDAO {
	//해당 유저 위치 정보
	public String userAddr(String user_nick) throws Exception;
	
	//시공업체 기본 리스트
	public List<InteriorDTO> locList(String addr) throws Exception;
	
	//시공업체 더보기 리스트
	public List<InteriorDTO> moreLocList(InteriorDTO dto) throws Exception;
	
	//해당 유저 업체명
	public String userComName(String user_nick) throws Exception;
	
	//해당 업체 정보
	public InteriorDTO companyInfo(InteriorDTO dto) throws Exception;
	
	//해당 업체 리뷰 기본 리스트
	public List<InteriorDTO> comReivew(String com_name) throws Exception;
	
	//해당 업체 리뷰 더보기 리스트
	public List<InteriorDTO> moreReList(InteriorDTO dto) throws Exception;
	
	//해당 업체 사례 기본 리스트
	public List<InteriorDTO> comExample(String com_name) throws Exception;
		
	//해당 업체 사례 더보기 리스트
	public List<InteriorDTO> moreExList(InteriorDTO dto) throws Exception;
	
	//등록전인 업체명 받아오기
	public List<String> notInCompany() throws Exception;
	
	//업체 등록하기
	public void companyRegist(InteriorDTO dto) throws Exception;
}
