package com.green.dehome.service;

import java.util.List;

import com.green.dehome.dto.ChatDTO;

public interface ChatService {
	//채팅 입력
	public void chatInsert(ChatDTO dto) throws Exception;
	//채팅내용 가져오기
	public List<ChatDTO> chatSelect(ChatDTO dto) throws Exception;
	//채팅내용 가져오기100개 제한
	public List<ChatDTO> chatSelectLimit(ChatDTO dto) throws Exception;
	//판매자일 경우 상대닉네임 가져오기
	public String getNick(ChatDTO dto) throws Exception;
	//대화리스트 가져오기
	public List<ChatDTO> chatList(ChatDTO dto) throws Exception;
	
	//채팅 입력
	public void insertChatCoun(ChatDTO dto) throws Exception;
	//채팅내용 가져오기
	public List<ChatDTO> selectChatCoun(ChatDTO dto) throws Exception;
	//채팅내용 가져오기100개 제한
	public List<ChatDTO> selectChatLimitCoun(ChatDTO dto) throws Exception;
	//판매자일 경우 상대닉네임 가져오기
	public String getNickCoun(ChatDTO dto) throws Exception;
	//대화리스트 가져오기
	public List<ChatDTO> getChatListCoun(ChatDTO dto) throws Exception;
}
